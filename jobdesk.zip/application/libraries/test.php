<?php
 Class test {
    public function view(){
        echo "all are good";
    }
 }