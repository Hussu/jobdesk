<div class="main-wrapper no-margin">
  <div class="container">
    <h2>Welcome User</h2>
  </div>
</div>
