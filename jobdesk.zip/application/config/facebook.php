<?php if (!defined('BASEPATH')) exit('No direct script access allowed');


$config['appId']   = '1021116384574894';
$config['secret']  = '17bf1452465fb81b4b61b48b4e6b0630';

?>
